<?php

namespace jeremykenedy\LaravelRoles\App\Http\Requests;

class UpdateRoleRequest extends StoreRoleRequest
{
    //
}
