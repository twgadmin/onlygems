<?php

namespace jeremykenedy\LaravelRoles\App\Http\Requests;

class UpdatePermissionRequest extends StorePermissionRequest
{
    //
}
