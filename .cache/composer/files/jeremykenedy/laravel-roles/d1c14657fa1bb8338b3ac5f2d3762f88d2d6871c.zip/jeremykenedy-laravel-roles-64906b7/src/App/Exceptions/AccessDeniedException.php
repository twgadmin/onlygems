<?php

namespace jeremykenedy\LaravelRoles\App\Exceptions;

use Exception;

class AccessDeniedException extends Exception
{
    //
}
