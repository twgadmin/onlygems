<?php

namespace jeremykenedy\LaravelBlocker\App\Http\Requests;

class UpdateBlockerRequest extends StoreBlockerRequest
{
    //
}
