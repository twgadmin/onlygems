<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Laravel Https Language Lines
    |--------------------------------------------------------------------------
    */
    'messages' => [
        'httpsRequredError' => '403 | Forbidden',
        'httpsRequred'      => 'SSL(HTTPS) is required to view',
    ],

];
