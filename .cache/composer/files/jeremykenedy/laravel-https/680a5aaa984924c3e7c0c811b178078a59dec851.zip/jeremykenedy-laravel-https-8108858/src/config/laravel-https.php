<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Laravel Https Settings
    |--------------------------------------------------------------------------
    */

    'httpsAccessDeniedErrorCode'  => env('LARAVEL_HTTP_ERROR_CODE', 403),

];
