<?php

defined('BASE_PATH') || define('BASE_PATH', realpath(__DIR__));

require dirname(__DIR__).'/vendor/autoload.php';
