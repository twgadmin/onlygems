<?php namespace Creativeorange\Gravatar\Exceptions;

class InvalidEmailException extends \Exception {}