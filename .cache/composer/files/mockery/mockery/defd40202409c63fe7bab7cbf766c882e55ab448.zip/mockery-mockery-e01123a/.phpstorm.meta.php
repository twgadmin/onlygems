<?php

namespace PHPSTORM_META;

override(\Mockery::mock(0), type(0));
override(\Mockery::spy(0), type(0));
override(\Mockery::namedMock(0), type(0));
override(\Mockery::instanceMock(0), type(0));
override(\mock(0), type(0));
override(\spy(0), type(0));
override(\namedMock(0), type(0));