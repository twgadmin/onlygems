<?php
namespace Aws\KinesisVideoSignalingChannels\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Amazon Kinesis Video Signaling Channels** service.
 */
class KinesisVideoSignalingChannelsException extends AwsException {}
