<?php

namespace SocialiteProviders\Manager\Contracts;

interface ConfigInterface
{
    /**
     * @return array
     */
    public function get();
}
